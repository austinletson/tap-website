function playVideo () {
    $("#content").fadeOut(800);
    //Add code to play video
}
